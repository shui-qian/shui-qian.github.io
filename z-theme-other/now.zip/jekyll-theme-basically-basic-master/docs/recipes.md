---
title: Recipes
layout: collection
permalink: /recipes/
collection: recipes
entries_layout: grid
---

Sample document listing for the collection `_recipes`.
